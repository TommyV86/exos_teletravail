<?php

function tableau()
{
    $tab = array(1, 1, 1, 1, 1, 1, 1);
    foreach ($tab as $value) {
        $value = $value * 0;
        echo ($value);
    }
}
tableau();
