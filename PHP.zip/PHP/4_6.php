<?php

    $input1 = readline("enter a 1st score: ");
    $input2 = readline("enter a 2nd score: ");
    $input3 = readline("enter a 3rd score: ");
    $input4 = readline("enter a 4th score: ");

    function guignol($score1,$score2,$score3,$score4){
        if($score1 > $score2){
            
        }
    }

    guignol($input1,$input2,$input3,$input4);    