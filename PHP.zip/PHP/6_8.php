<?php

function tableau()
{
    $tab = array();
    $stock = 0;
    for ($i = 0; $i < 5; $i++) {
        
        $input = readline("enter a number : ");
        $stock += $input ;
        $tab[] = $stock;
        
        if($stock > 0){
            $numPos = 0;
            $stock += $numPos;
            echo $numPos;
        } else {
            $numbNeg = 0;
            $stock += $numbNeg;
            echo $numbNeg;
        }
    }
    
    print_r($tab);
}
tableau();