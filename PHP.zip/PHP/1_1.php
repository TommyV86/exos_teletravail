<?php

    $b = "the number is positive";
    $c = "the number is negative";

    $a = readline("enter a number: " );
    if ($a > 0) 
        echo $b;
    else
        echo $c;