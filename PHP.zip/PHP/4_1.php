<?php 

    $tutu = 1;
    $toto = 2;
    $tete = "ok";

    if ($tutu > $toto || $tete == "ok")
        $tutu += 1;
    else
        $tutu -= 1;

    echo $tutu;